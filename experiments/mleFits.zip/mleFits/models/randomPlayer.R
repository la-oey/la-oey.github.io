

randomSender.pred <- function(){
  matrix(1/11, nrow=121, ncol=6)
}


randomReceiver.pred <- function(){
  matrix(0.5, nrow=11, ncol=6)
}


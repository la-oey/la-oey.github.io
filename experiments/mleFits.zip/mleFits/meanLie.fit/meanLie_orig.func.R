


p.lie.k <- function(k, beta, mu){
  logodds = beta * (k-mu)
  logitToProb(pmin(10, pmax(-10, logodds)))
}


p.kstar.k <- function(k, kstar, alph){
  alph = logitToProb(alph)
  dbinom(kstar, 10, alph) / (1-dbinom(k, 10, alph))  
}

lieLogisticBinom <- function(k, kstar, beta, mu, alph){
  p.lie = p.lie.k(k, beta, mu)
  ifelse(k == kstar, 1 - p.lie, p.lie * p.kstar.k(k, kstar, alph))
}



lieLL <- function(datafr,
                        beta, 
                        mu0.2_4, alph0.2_4,
                        mu0.5_4, alph0.5_4,
                        mu0.8_4, alph0.8_4,
                        mu0.2_5, alph0.2_5,
                        mu0.5_5, alph0.5_5,
                        mu0.8_5, alph0.8_5){
  k = datafr$k
  kstar = datafr$k.star
  expt = datafr$expt
  prob = datafr$p
  mu = case_when(
    prob == 0.2 & expt == "expt4" ~ mu0.2_4,
    prob == 0.5 & expt == "expt4" ~ mu0.5_4,
    prob == 0.8 & expt == "expt4" ~ mu0.8_4,
    prob == 0.2 & expt == "expt5" ~ mu0.2_5,
    prob == 0.5 & expt == "expt5" ~ mu0.5_5,
    prob == 0.8 & expt == "expt5" ~ mu0.8_5
  )
  alph = case_when(
    prob == 0.2 & expt == "expt4" ~ alph0.2_4,
    prob == 0.5 & expt == "expt4" ~ alph0.5_4,
    prob == 0.8 & expt == "expt4" ~ alph0.8_4,
    prob == 0.2 & expt == "expt5" ~ alph0.2_5,
    prob == 0.5 & expt == "expt5" ~ alph0.5_5,
    prob == 0.8 & expt == "expt5" ~ alph0.8_5
  )
  
  betas = ifelse(expt=="expt4", 1*beta, -1*beta)
  
  pred = lieLogisticBinom(k, kstar, betas, mu, alph)
  
  # likelihood of observed kstar for that k, given parameters
  neg.log.lik = -1*sum(log(pmax(pred, 0.0001)))
  neg.log.lik
}



fit <- function(datafr){
  LL = function(beta, 
                mu0.2_4, alph0.2_4,
                mu0.5_4, alph0.5_4,
                mu0.8_4, alph0.8_4,
                mu0.2_5, alph0.2_5,
                mu0.5_5, alph0.5_5,
                mu0.8_5, alph0.8_5){
    lieLL(datafr, 
          beta, 
          mu0.2_4, alph0.2_4,
          mu0.5_4, alph0.5_4,
          mu0.8_4, alph0.8_4,
          mu0.2_5, alph0.2_5,
          mu0.5_5, alph0.5_5,
          mu0.8_5, alph0.8_5)
  }
  summary(mle(LL, start=list(beta=rnorm(1, 0, 0.5),
                             mu0.2_4=rnorm(1, 5, 3),
                             alph0.2_4=rnorm(1, 0, 0.5),
                             mu0.5_4=rnorm(1, 5, 3),
                             alph0.5_4=rnorm(1, 0, 0.5),
                             mu0.8_4=rnorm(1, 5, 3),
                             alph0.8_4=rnorm(1, 0, 0.5),
                             mu0.2_5=rnorm(1, 5, 3),
                             alph0.2_5=rnorm(1, 0, 0.5),
                             mu0.5_5=rnorm(1, 5, 3),
                             alph0.5_5=rnorm(1, 0, 0.5),
                             mu0.8_5=rnorm(1, 5, 3),
                             alph0.8_5=rnorm(1, 0, 0.5)),
              method = "BFGS"))
}


source('meanLie_orig.func.R')


recurseToM.pred.kstar <- recurseToM.pred(
  recurseToMeval@coef['alph','Estimate'],
  recurseToMeval@coef['eta.S','Estimate'],
  recurseToMeval@coef['eta.R','Estimate'],
  recurseToMeval@coef['lambda','Estimate'])[[2]]
recurseToM.predicted <- round(recurseToM.pred.kstar * kmatrix)


countRecurseLie <- plyr::adply(recurseToM.predicted, 1:3) %>%
  mutate_at(c("X1","X2","X3"), as.numeric) %>%
  rename(
    k.star=X1, 
    k=X2, 
    counts=V1) %>%
  mutate(expt = ifelse(X3<=3, "expt4", "expt5"),
         p = case_when(
           X3 %% 3 == 1 ~ 0.2,
           X3 %% 3 == 2 ~ 0.5,
           X3 %% 3 == 0 ~ 0.8
         )) %>%
  select(-X3) %>%
  uncount(weights=counts)

origMLE <- fit(countRecurseLie)



recurseToMlie
